import io from "./dist/index.js";

export const Server = io.Server;
