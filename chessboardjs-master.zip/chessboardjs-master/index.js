<!doctype html>
<html lang="en">

<head>
 <meta charset="UTF-8" />
 <title>Chess 0</title>
  
 <script src="https://cdnjs.cloudflare.com/ajax/libs/chess.js/0.10.2/chess.js"></script>
 <script src="./chessboard/js/chessboard-0.3.0.min.js"></script>
 <link rel="stylesheet" href="./chessboard/css/chessboard-0.3.0.min.css">
 <style>
   body{
     margin: 4%
   }
 </style>

</head>

<body>

 <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.1.1/socket.io.js"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <div class="container">
       <div id="board" style="width: 500px; margin: auto"></div>
   </div>
  
 </div>

 <script src="./game.js"></script>

</body>

</html>