var config = {
  position: 'start',
  draggable: true
}


var board = ChessBoard('board', config);
